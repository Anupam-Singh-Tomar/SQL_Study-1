use supply_db ;

/*
Question : Golf related products

List all products in categories related to golf. Display the Product_Id, Product_Name in the output. Sort the output in the order of product id.
Hint: You can identify a Golf category by the name of the category that contains golf.

*/
select Product_Name , Product_Id
 from product_info p inner join category c on p.Category_Id=c.Id
 where Name Like '%Golf%'
group by Product_Id 
order by Product_Id;
-- **********************************************************************************************************************************

/*
Question : Most sold golf products

Find the top 10 most sold products (based on sales) in categories related to golf. Display the Product_Name and Sales column in the output. Sort the output in the descending order of sales.
Hint: You can identify a Golf category by the name of the category that contains golf.

HINT:
Use orders, ordered_items, product_info, and category tables from the Supply chain dataset.


*/
select
Product_Name,
Sales
from
(
select
prod_info.Product_Name,
SUM(Sales) as Sales,
rank() over(order by SUM(Sales) desc) as Sales_Rank
from
orders as ord
left join
ordered_items as ord_itm
ON ord.Order_Id = ord_itm.Order_Id
left join
product_info as prod_info
on ord_itm.Item_Id=prod_info.Product_Id
left join
category as cat
on prod_info.Category_Id =cat.Id
where
lower(cat.Name) like '%golf%'
group by prod_info.Product_Name
order by Sales desc
) as summary
where Sales_Rank<=10;
-- **********************************************************************************************************************************

/*
Question: Segment wise orders

Find the number of orders by each customer segment for orders. Sort the result from the highest to the lowest 
number of orders.The output table should have the following information:
-Customer_segment
-Orders


*/
select
cust.Segment as customer_segment,
COUNT(ord.Order_Id) as Orders
from
orders as ord
inner join

customer_info as cust
on ord.Customer_Id = cust.Id
group by customer_segment
order by Orders desc;
-- **********************************************************************************************************************************
/*
Question : Percentage of order split

Description: Find the percentage of split of orders by each customer segment for orders that took six days 
to ship (based on Real_Shipping_Days). Sort the result from the highest to the lowest percentage of split orders,
rounding off to one decimal place. The output table should have the following information:
-Customer_segment
-Percentage_order_split

HINT:
Use the orders and customer_info tables from the Supply chain dataset.


*/
with Segment_Orders as
(
select
cust.Segment as customer_segment,
count(ord.Order_Id) as Orders
from
orders as ord
left join
customer_info as cust
on ord.Customer_Id = cust.Id
where Real_Shipping_Days=6
group by customer_segment
)
select
a.customer_segment,
ROUND(a.Orders/SUM(b.Orders)*100,1) as percentage_order_split
from
Segment_Orders as a
join
Segment_Orders as b
group by a.customer_segment
order by percentage_order_split desc;
-- **********************************************************************************************************************************
